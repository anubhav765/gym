namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class payment : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblpayments",
                c => new
                    {
                        Pay_id = c.Int(nullable: false, identity: true),
                        Pay_amount = c.Int(nullable: false),
                        Customer_id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Pay_id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.tblpayments");
        }
    }
}
