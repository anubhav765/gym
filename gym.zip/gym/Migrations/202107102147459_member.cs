﻿namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class member : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblMembers",
                c => new
                    {
                        MID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Mobile = c.String(),
                        Email = c.String(),
                        Address = c.String(),
                        City = c.String(),
                        State = c.String(),
                    })
                .PrimaryKey(t => t.MID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.tblMembers");
        }
    }
}
