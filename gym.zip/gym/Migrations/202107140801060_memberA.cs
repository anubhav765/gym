namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class memberA : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.tblMembers", "City");
            DropColumn("dbo.tblMembers", "State");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tblMembers", "State", c => c.String());
            AddColumn("dbo.tblMembers", "City", c => c.String());
        }
    }
}
