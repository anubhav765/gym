namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class trainer : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tbltrainers",
                c => new
                    {
                        trnr_id = c.Int(nullable: false, identity: true),
                        trnr_mobile = c.String(),
                        trnr_name = c.String(),
                        trnr_address = c.String(),
                        trnr_pass = c.String(),
                    })
                .PrimaryKey(t => t.trnr_id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.tbltrainers");
        }
    }
}
