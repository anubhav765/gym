namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class fitness : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblGyms",
                c => new
                    {
                        gym_id = c.Int(nullable: false, identity: true),
                        gym_crossfit = c.String(),
                        gym_powerlifting = c.String(),
                    })
                .PrimaryKey(t => t.gym_id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.tblGyms");
        }
    }
}
