namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class permis : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tblPermissions", "role_id_role_id", c => c.Int());
            CreateIndex("dbo.tblPermissions", "role_id_role_id");
            AddForeignKey("dbo.tblPermissions", "role_id_role_id", "dbo.tblRoles", "role_id");
            DropColumn("dbo.tblPermissions", "per_role_id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tblPermissions", "per_role_id", c => c.Int(nullable: false));
            DropForeignKey("dbo.tblPermissions", "role_id_role_id", "dbo.tblRoles");
            DropIndex("dbo.tblPermissions", new[] { "role_id_role_id" });
            DropColumn("dbo.tblPermissions", "role_id_role_id");
        }
    }
}
