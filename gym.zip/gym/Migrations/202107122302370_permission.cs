namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class permission : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblPermissions",
                c => new
                    {
                        per_id = c.Int(nullable: false, identity: true),
                        per_role_id = c.Int(nullable: false),
                        per_name = c.String(),
                    })
                .PrimaryKey(t => t.per_id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.tblPermissions");
        }
    }
}
