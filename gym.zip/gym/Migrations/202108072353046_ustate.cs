namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ustate : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tblUsers", "Ustate", c => c.Int(nullable: false));
            DropColumn("dbo.tblStates", "StateIsoCode");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tblStates", "StateIsoCode", c => c.String());
            DropColumn("dbo.tblUsers", "Ustate");
        }
    }
}
