namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class login1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tblLogins", "role_id_role_id", c => c.Int());
            AddColumn("dbo.tblLogins", "UID_UID", c => c.Int());
            CreateIndex("dbo.tblLogins", "role_id_role_id");
            CreateIndex("dbo.tblLogins", "UID_UID");
            AddForeignKey("dbo.tblLogins", "role_id_role_id", "dbo.tblRoles", "role_id");
            AddForeignKey("dbo.tblLogins", "UID_UID", "dbo.tblUsers", "UID");
            DropColumn("dbo.tblLogins", "Login_role_id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tblLogins", "Login_role_id", c => c.Int(nullable: false));
            DropForeignKey("dbo.tblLogins", "UID_UID", "dbo.tblUsers");
            DropForeignKey("dbo.tblLogins", "role_id_role_id", "dbo.tblRoles");
            DropIndex("dbo.tblLogins", new[] { "UID_UID" });
            DropIndex("dbo.tblLogins", new[] { "role_id_role_id" });
            DropColumn("dbo.tblLogins", "UID_UID");
            DropColumn("dbo.tblLogins", "role_id_role_id");
        }
    }
}
