namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class login : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblLogins",
                c => new
                    {
                        Login_id = c.Int(nullable: false, identity: true),
                        Login_role_id = c.Int(nullable: false),
                        Login_username = c.String(),
                        user_password = c.String(),
                    })
                .PrimaryKey(t => t.Login_id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.tblLogins");
        }
    }
}
