namespace gym.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class user : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblUsers",
                c => new
                    {
                        UID = c.Int(nullable: false, identity: true),
                        Uname = c.String(),
                        Umobile = c.String(),
                        Uemail = c.String(),
                        Uaddress = c.String(),
                    })
                .PrimaryKey(t => t.UID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.tblUsers");
        }
    }
}
