﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tblCountry
    {
        [Key]

        public int CountryID { get; set; }

        public string CountryName { get; set; }

        public ushort CountryCode { get; set; }

        public string CountryIsoCode { get; set; }

    }
}