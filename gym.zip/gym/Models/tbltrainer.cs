﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tbltrainer
    {
        [Key]

        public int trnr_id { get; set; }

        public string trnr_mobile { get; set; }

        public string trnr_name { get; set; }

        public string trnr_address { get; set; }

        public string trnr_pass { get; set; }

        public int t_country { get; set; }

        public int t_state { get; set; }

    }
}