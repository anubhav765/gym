﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tblUser
    {
        [Key]

        public int UID { get; set; }

        public string Uname { get; set; }

        public string Umobile { get; set; }
        
        public string Uemail { get; set; }

        public string Uaddress { get; set; }

        public int Ucountry { get; set; }

        public int Ustate { get; set; }

    }
}