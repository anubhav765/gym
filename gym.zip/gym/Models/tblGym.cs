﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tblGym
    {
        [Key]
        public int gym_id { get; set; }

        public string gym_crossfit { get; set; }

        public string gym_powerlifting { get; set; }

    }
}