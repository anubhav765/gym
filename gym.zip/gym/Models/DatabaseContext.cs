﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("gymdb")
        {

        }
        public DbSet<tblMember> tblMembers { get; set; }

        public DbSet<tblUser> tblUsers { get; set; }

        public DbSet<tblLogin> tblLogins { get; set; }

        public DbSet<tblRole> tblRoles { get; set; }

        public DbSet<tblPermission> tblPermissions { get; set; }

        public DbSet<tbltrainer> tbltrainers { get; set; }

        public DbSet<tblpayment> tblpayments { get; set; }

        public DbSet<tblGym> tblGyms { get; set; }

        public DbSet<tblCountry> tblCountries { get; set; }

        public DbSet<tblState> tblStates { get; set; }



    }
}