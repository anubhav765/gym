﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tblRole
    {
        [Key]

        public int role_id { get; set; }
        
        public string role_name { get; set; }

    }
}