﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tblLogin
    {
        [Key]
        public int Login_id { get; set; }

        public string Login_username { get; set; }
        
        public string user_password { get; set; } 

        public tblRole role_id { get; set; }

        public tblUser UID { get; set; }

        
    }
}