﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tblpayment
    {
        [Key]
        public int Pay_id { get; set; }

        public int Pay_amount { get; set; }
        
        public int Customer_id { get; set; }

    }
}