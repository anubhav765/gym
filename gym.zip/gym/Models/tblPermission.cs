﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace gym.Models
{
    public class tblPermission
    {
        [Key]

        public int per_id { get; set; }
        
        public string per_name { get; set; }

        public tblRole role_id { get; set; }

    }
}
