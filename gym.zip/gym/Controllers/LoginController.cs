﻿using gym.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gym.Controllers
{
    public class LoginController : Controller
    {
        DatabaseContext _db = new Models.DatabaseContext();
        // GET: Login
        public ActionResult LoginCreate()
        {
            return View();
        }
        [HttpPost]
        public ActionResult LoginCreate(tblLogin _tblLogin)
        {
            _db.tblLogins.Add(_tblLogin);
            _db.SaveChanges();
            return RedirectToAction("LoginDisplay");
        }

        public ActionResult LoginDisplay()
        {
            var file = _db.tblLogins.ToList();
            return View(file);
        }
    }
}