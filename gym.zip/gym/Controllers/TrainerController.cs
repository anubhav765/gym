﻿using gym.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gym.Controllers
{
    public class TrainerController : Controller
    {
        DatabaseContext _db = new Models.DatabaseContext();
        // GET: Trainer
        public ActionResult TrainerCreate()
        {
            return View();
        }

        [HttpPost]

        public ActionResult TrainerCreate(tbltrainer _tbltrainer)
        {
            _db.tbltrainers.Add(_tbltrainer);
            _db.SaveChanges();
            return RedirectToAction("TrainerDisplay");
        }
        public ActionResult TrainerDisplay()
        {
           var file = _db.tbltrainers.ToList();
            return View(file);
        }

    }
}