﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using gym.Models;

namespace gym.Controllers
{
    public class MemController : Controller
    {
        // GET: Mem
        DatabaseContext _db = new Models.DatabaseContext();
        public ActionResult MemberCreate()
        {
            return View();
        }

        [HttpPost]
        public ActionResult MemberCreate(tblMember _tblmember)
        {
            _db.tblMembers.Add(_tblmember);
            _db.SaveChanges();
            return RedirectToAction("MemberDisplay");
        }


        public ActionResult MemberDisplay()
        {
            var File = _db.tblMembers.ToList();
            return View(File);
        }

        public ActionResult MemberDelete(int id )
        {
            var file = _db.tblMembers.Find(id);
            _db.tblMembers.Remove(file);
            _db.SaveChanges();
            return RedirectToAction("MemberDisplay");
        }



    }
}