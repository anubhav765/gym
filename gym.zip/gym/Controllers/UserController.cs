﻿using gym.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gym.Controllers
{
    public class UserController : Controller
    {
        DatabaseContext _db = new Models.DatabaseContext();
        // GET: User
        public ActionResult UserCreate( int id= 0)
        {
            ViewBag.BT = "SAVE";
            tblUser _tblUser = new tblUser();
            if (id > 0)
            {
                
                var file = (from USER_A in _db.tblUsers where USER_A.UID == id select USER_A).ToList();
                _tblUser.UID = file[0].UID;
                _tblUser.Uname = file[0].Uname;
                _tblUser.Umobile = file[0].Umobile;
                _tblUser.Uemail = file[0].Uemail;
                _tblUser.Uaddress = file[0].Uaddress;
                _tblUser.Ucountry = file[0].Ucountry;
                _tblUser.Ustate = file[0].Ustate;
                ViewBag.BT = "UPDATE";
            }
            ViewBag.CTR = _db.tblCountries.ToList();
            ViewBag.STR = (from USER_A in _db.tblStates where USER_A.CountryID == _tblUser.Ucountry select USER_A).ToList();
            return View(_tblUser);

        }

        [HttpPost]
        public ActionResult UserCreate(tblUser _tblUser)
        {
            if (_tblUser.UID > 0)
            {
                _db.Entry(_tblUser).State = System.Data.Entity.EntityState.Modified;
            }
            else
            {
                _db.tblUsers.Add(_tblUser);
            }
            _db.SaveChanges();
            return RedirectToAction("UserDisplay");
        }


        public ActionResult UserDisplay()
        {
            var file = (from USER_A in _db.tblUsers
                        join USER_B in _db.tblCountries on USER_A.Ucountry equals USER_B.CountryID
                        join USER_C in _db.tblStates on USER_A.Ustate equals USER_C.StateID
                        select new User_New_
                        {
                            UID = USER_A.UID,
                            Uname = USER_A.Uname,
                            Umobile = USER_A.Umobile,
                            Uemail = USER_A.Uemail,
                            Uaddress = USER_A.Uaddress,
                            CountryName = USER_B.CountryName,
                            StateName = USER_C.StateName,
                        }).ToList();
            return View(file);


            //var file = _db.tblUsers.ToList();
            //return View(file);
        }
        public ActionResult UserDelete(int id)
        {
            var file = _db.tblUsers.Find(id);
            _db.tblUsers.Remove(file);
            _db.SaveChanges();
            return RedirectToAction("UserDisplay");
        }

        public JsonResult GetState(int A)
        {
            var file = (from USER_A in _db.tblStates where USER_A.CountryID==A select USER_A).ToList();
            return Json(file, JsonRequestBehavior.AllowGet);
        }

    }
}