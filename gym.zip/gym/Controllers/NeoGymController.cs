﻿using gym.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gym.Controllers
{
    public class NeoGymController : Controller
    {
        DatabaseContext _db = new Models.DatabaseContext();
        // GET: NeoGym
        public ActionResult NeoGymCreate()
        {
            return View();
        }


        [HttpPost]
        public ActionResult NeoGymCreate(tblGym _tblGym)
        {
            _db.tblGyms.Add(_tblGym);
            _db.SaveChanges();
            return RedirectToAction("NeoGymDisplay");
        }


        public ActionResult NeoGymDisplay()
        {
            var File = _db.tblGyms.ToList();
            return View(File);
        }


    }
}