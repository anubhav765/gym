﻿using gym.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gym.Controllers
{
    public class RoleController : Controller
    {
        DatabaseContext _db = new Models.DatabaseContext();
        // GET: Role
        public ActionResult RoleCreate()
        {
            return View();
        }
        [HttpPost]

        public ActionResult RoleCreate(tblRole _tblRole)
        {
            _db.tblRoles.Add(_tblRole);
            _db.SaveChanges();
            return RedirectToAction("RoleDisplay");
        }

        public ActionResult RoleDisplay()
        {
            var File = _db.tblRoles.ToList();
            return View(File);
        }


    }
}