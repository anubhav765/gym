﻿using gym.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gym.Controllers
{
    public class PaymentController : Controller
    {
        DatabaseContext _db = new Models.DatabaseContext();
        // GET: Payment
        public ActionResult PaymentCreate()
        {
            return View();
        }


        [HttpPost]
        public ActionResult PaymentCreate(tblpayment _tblpayment)
        {
            _db.tblpayments.Add(_tblpayment);
            _db.SaveChanges();
            return RedirectToAction("PaymentDisplay");
        }


        public ActionResult PaymentDisplay()
        {
            var File = _db.tblpayments.ToList();
            return View(File);
        }




    }
}