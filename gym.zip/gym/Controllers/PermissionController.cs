﻿using gym.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace gym.Controllers
{
    public class PermissionController : Controller
    {
        DatabaseContext _db = new Models.DatabaseContext();
        // GET: Permission
        public ActionResult PermissionCreate()
        {
            return View();
        }



        [HttpPost]
        public ActionResult PermissionCreate(tblPermission _tblPermission)
        {
            _db.tblPermissions.Add(_tblPermission);
            _db.SaveChanges();
            return RedirectToAction("PermissionDisplay");
        }


        public ActionResult PermissionDisplay()
        {
            var File = _db.tblPermissions.ToList();
            return View(File);
        }




    }
}